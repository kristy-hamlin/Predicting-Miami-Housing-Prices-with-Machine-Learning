Miami Housing Price Prediction using Decision Tree Regressor
Kristy Hamlin
3354342
Machine Learning


I have completed the code for this project using Jupyter Notebooks. It uses Pandas, matplotlib, Numpy, StandardScaler, train_test_split, and DecisionTreeRegressor (the last 3 are from sklearn).

My Jupyter Notebook has the code and notes about what I did and why. It can be rerun in Jupyter Notebooks, or you can see my output and notes saved in the notebook without running it again. 

This class is my first time using Jupyter Notebooks, so one thing I noticed was that whenever I closed and reopened the notebook I needed to rerun all the cells to continue working. This resulted in the line numbers being very high in the code. I am unsure what the convention is for working on a Jupyter Notebook in multiple sittings. 